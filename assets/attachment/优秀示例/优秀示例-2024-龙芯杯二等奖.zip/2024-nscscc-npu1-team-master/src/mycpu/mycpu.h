`ifndef MYCPU_H
    `define MYCPU_H

    `define BR_BUS_WD       34
    `define FS_TO_DS_BUS_WD 71
    `define DS_TO_ES_BUS_WD 297
    `define DS_TO_ES_BR_WD 74
    `define ES_TO_PMS_BUS_WD 378
    `define PMS_TO_MS_BUS_WD 363
    `define MS_TO_WS_BUS_WD 361
    `define WS_TO_RF_BUS_WD 38
`endif